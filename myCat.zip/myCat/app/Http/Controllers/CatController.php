<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Cat;
class CatController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
         $data= Cat::all();
        return view('cats/index',['cats'=>$data]);
    
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
   

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
   
         public function createPage()
    {
        return view('cats/create');
    }
         public function showPage()
    {
        return view('cats/show');
    }
    function addData(Request $req){
        $cat= new Cat;
        $cat->name=$req->name;
        $cat->date_of_birth=$req->date_of_birth;
        $cat->save();

        echo "Successfully Saved Data";

    }
    function delete($id){
        $data=Cat::find($id);
        $data->delete();
        return redirect('index');
    }
    function showData($id){
        $data= Cat::find($id);
        return view('cats/edit',['data'=>$data]);
    }
    function edit(Request $req){
        $data=Cat::find($req->id);
        $data->name=$req->name;
        $data->date_of_birth=$req->date_of_birth;
        $data->save();
         //echo "Successfully Data Updated";
        return redirect('index');
    }
}
