<h1>Update Cat Details</h1>
<form action="/edit" method="POST">
	<?php echo csrf_field(); ?>
	<input type="hidden" name="id" value="<?php echo e($data['id']); ?>">
	<input type="text" name="name" value="<?php echo e($data['name']); ?>"><br><br>
	<input type="date" name="date_of_birth"  value="<?php echo e($data['date_of_birth']); ?>"><br><br>
	<button type="submit">Update</button>
</form><?php /**PATH C:\Users\User\myCat\resources\views/cats/edit.blade.php ENDPATH**/ ?>