Laravel

<?php /**PATH C:\Users\User\myCat\resources\views/welcome.blade.php ENDPATH**/ ?>