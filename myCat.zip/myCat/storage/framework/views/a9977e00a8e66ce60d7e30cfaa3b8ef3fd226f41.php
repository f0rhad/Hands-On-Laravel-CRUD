<h1>Add New Cat Details</h1>
<form action="create" method="POST">
	<?php echo csrf_field(); ?>
	<input type="text" name="name" placeholder="Enter Name"><br><br>
	<input type="date" name="date_of_birth" placeholder="date_of_birth"><br><br>
	<button type="submit">Add Info</button>
</form><?php /**PATH C:\Users\User\myCat\resources\views/cats/create.blade.php ENDPATH**/ ?>