<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\catController;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});
Route::get('/index','App\Http\Controllers\catController@index')->name('index');

Route::get('/create','App\Http\Controllers\catController@createPage')->name('create');
Route::get('/show','App\Http\Controllers\catController@showPage')->name('show');

Route::post('/create','App\Http\Controllers\catController@addData')->name('addData');
Route::get('delete/{id}',[catController::class,'delete']);
Route::get('edit/{id}',[catController::class,'showData']);
Route::post('edit',[catController::class,'edit']);