<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
<style>
#customers {
  font-family: Arial, Helvetica, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

#customers td, #customers th {
  border: 1px solid #ddd;
  padding: 8px;
}

#customers tr:nth-child(even){background-color: #f2f2f2;}

#customers tr:hover {background-color: #ddd;}

#customers th {
  padding-top: 12px;
  padding-bottom: 12px;
  text-align: left;
  background-color: #4CAF50;
  color: white;
}
.block {
  display: block;
  width: 100%;
  border: none;
  background-color: #04AA6D;
  color: white;
  padding: 14px 28px;
  font-size: 16px;
  cursor: pointer;
  text-align: center;
}

.block:hover {
  background-color: #ddd;
  color: black;
}
</style>
</head>
<body>
  <br>
<h1 style="text-align: center;">Our Cat List</h1><br>
<table id="customers">
  <tr>
    <th>No</th>
    <th>Name</th>
    <th>Date Of Birth</th>
    <th>Action</th>
  </tr>
  @foreach($cats as $cat)
  <tr>
    <td>{{$cat['id']}}</td>
    <td>{{$cat['name']}}</td>
    <td>{{$cat['date_of_birth']}}</td>
    <td><a href="edit/{{$cat['id']}}"><button type="button"  class="btn btn-primary">Edit</button></a>
      <a href="delete/{{$cat['id']}}"><button type="button" class="btn btn-danger">Delete</button></a></td>
  </tr>
 @endforeach

</table>
<br> <br>
<a href="{{route('create')}}"><button type="button" class="block">New Cat Details</button></a>
</body>
</html>
