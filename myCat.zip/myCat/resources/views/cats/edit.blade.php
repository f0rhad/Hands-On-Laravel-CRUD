<h1>Update Cat Details</h1>
<form action="/edit" method="POST">
	@csrf
	<input type="hidden" name="id" value="{{$data['id']}}">
	<input type="text" name="name" value="{{$data['name']}}"><br><br>
	<input type="date" name="date_of_birth"  value="{{$data['date_of_birth']}}"><br><br>
	<button type="submit">Update</button>
</form>